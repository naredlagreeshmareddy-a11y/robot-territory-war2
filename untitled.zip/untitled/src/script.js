const BOARD_SIZE = 5;
let board = [];
let humanPos = { r: 0, c: 0 };
let aiPos = { r: 4, c: 4 };
let isGameActive = true;
let turn = 'human'; 
let aiDepth = 3;

function initGame() {
    board = [];
    for (let r = 0; r < BOARD_SIZE; r++) {
        let row = [];
        for (let c = 0; c < BOARD_SIZE; c++) {
            row.push({ owner: null, bonus: null });
        }
        board.push(row);
    }

    humanPos = { r: 0, c: 0 };
    aiPos = { r: 4, c: 4 };

    board[0][0].owner = 'human';
    board[4][4].owner = 'ai';

    let bonusesPlaced = 0;
    while (bonusesPlaced < 4) {
        let rr = Math.floor(Math.random() * BOARD_SIZE);
        let rc = Math.floor(Math.random() * BOARD_SIZE);
        if ((rr !== 0 || rc !== 0) && (rr !== 4 || rc !== 4) && !board[rr][rc].bonus) {
            board[rr][rc].bonus = Math.random() > 0.5 ? 'star' : 'diamond';
            bonusesPlaced++;
        }
    }

    isGameActive = true;
    turn = 'human';
    renderBoard();
    updateScores();
    document.getElementById('status').textContent = "Your Turn (👤) - Click a green adjacent cell to move";
}

function changeDifficulty() {
    aiDepth = parseInt(document.getElementById('difficulty').value);
}

function getValidMoves(pos) {
    let moves = [];
    let dirs = [{r: -1, c: 0}, {r: 1, c: 0}, {r: 0, c: -1}, {r: 0, c: 1}];
    for (let d of dirs) {
        let nr = pos.r + d.r;
        let nc = pos.c + d.c;
        if (nr >= 0 && nr < BOARD_SIZE && nc >= 0 && nc < BOARD_SIZE) {
            if (!(nr === humanPos.r && nc === humanPos.c) && !(nr === aiPos.r && nc === aiPos.c)) {
                moves.push({ r: nr, c: nc });
            }
        }
    }
    return moves;
}

function renderBoard() {
    const boardElement = document.getElementById('board');
    boardElement.innerHTML = '';

    let validHumanMoves = turn === 'human' && isGameActive ? getValidMoves(humanPos) : [];

    for (let r = 0; r < BOARD_SIZE; r++) {
        for (let c = 0; c < BOARD_SIZE; c++) {
            const btn = document.createElement('button');
            btn.classList.add('cell');

            if (board[r][c].owner === 'human') btn.classList.add('human-territory');
            if (board[r][c].owner === 'ai') btn.classList.add('ai-territory');

            let isValid = validHumanMoves.some(m => m.r === r && m.c === c);
            if (isValid) {
                btn.classList.add('valid-move');
                btn.onclick = () => handleHumanMove(r, c);
            }

            let content = '';
            if (humanPos.r === r && humanPos.c === c) {
                content = '👤';
            } else if (aiPos.r === r && aiPos.c === c) {
                content = '🤖';
            } else if (board[r][c].bonus === 'star') {
                content = '⭐';
            } else if (board[r][c].bonus === 'diamond') {
                content = '💎';
            }
            btn.textContent = content;

            boardElement.appendChild(btn);
        }
    }
}

function updateScores() {
    let humanScore = 0;
    let aiScore = 0;

    for (let r = 0; r < BOARD_SIZE; r++) {
        for (let c = 0; c < BOARD_SIZE; c++) {
            if (board[r][c].owner === 'human') humanScore += 1;
            if (board[r][c].owner === 'ai') aiScore += 1;
        }
    }

    document.getElementById('human-score').textContent = humanScore;
    document.getElementById('ai-score').textContent = aiScore;
}

function handleHumanMove(r, c) {
    if (!isGameActive || turn !== 'human') return;

    humanPos = { r, c };
    board[r][c].owner = 'human';
    if (board[r][c].bonus) {
        board[r][c].bonus = null; 
    }

    updateScores();
    renderBoard();

    if (getValidMoves(aiPos).length === 0) {
        endGame();
        return;
    }

    turn = 'ai';
    document.getElementById('status').textContent = "AI is thinking (🤖)...";

    setTimeout(() => {
        aiTurn();
    }, 500);
}

function aiTurn() {
    if (!isGameActive) return;

    let bestMove = findBestAIMove();
    if (bestMove) {
        aiPos = { r: bestMove.r, c: bestMove.c };
        board[bestMove.r][bestMove.c].owner = 'ai';
        if (board[bestMove.r][bestMove.c].bonus) {
            board[bestMove.r][bestMove.c].bonus = null;
        }
    }

    updateScores();
    renderBoard();

    if (getValidMoves(humanPos).length === 0) {
        endGame();
    } else {
        turn = 'human';
        document.getElementById('status').textContent = "Your Turn (👤) - Click a green adjacent cell to move";
        renderBoard();
    }
}

function findBestAIMove() {
    let possibleMoves = getValidMoves(aiPos);
    if (possibleMoves.length === 0) return null;

    let bestScore = -Infinity;
    let bestMove = possibleMoves[0];

    for (let move of possibleMoves) {
        let prevOwner = board[move.r][move.c].owner;
        let prevBonus = board[move.r][move.c].bonus;
        let oldAiPos = { ...aiPos };

        aiPos = move;
        board[move.r][move.c].owner = 'ai';
        board[move.r][move.c].bonus = null;

        let score = minimax(aiDepth - 1, false, -Infinity, Infinity);

        aiPos = oldAiPos;
        board[move.r][move.c].owner = prevOwner;
        board[move.r][move.c].bonus = prevBonus;

        if (score > bestScore) {
            bestScore = score;
            bestMove = move;
        }
    }
    return bestMove;
}

function minimax(depth, isMaximizing, alpha, beta) {
    let humanMoves = getValidMoves(humanPos);
    let aiMoves = getValidMoves(aiPos);

    if (depth === 0 || (humanMoves.length === 0 && aiMoves.length === 0)) {
        return evaluateBoard();
    }

    if (isMaximizing) {
        let maxEval = -Infinity;
        for (let move of aiMoves) {
            let prevOwner = board[move.r][move.c].owner;
            let prevBonus = board[move.r][move.c].bonus;
            let oldAiPos = { ...aiPos };

            aiPos = move;
            board[move.r][move.c].owner = 'ai';
            board[move.r][move.c].bonus = null;

            let evaluation = minimax(depth - 1, false, alpha, beta);

            aiPos = oldAiPos;
            board[move.r][move.c].owner = prevOwner;
            board[move.r][move.c].bonus = prevBonus;

            maxEval = Math.max(maxEval, evaluation);
            alpha = Math.max(alpha, evaluation);
            if (beta <= alpha) break;
        }
        return maxEval;
    } else {
        let minEval = Infinity;
        for (let move of humanMoves) {
            let prevOwner = board[move.r][move.c].owner;
            let prevBonus = board[move.r][move.c].bonus;
            let oldHumanPos = { ...humanPos };

            humanPos = move;
            board[move.r][move.c].owner = 'human';
            board[move.r][move.c].bonus = null;

            let evaluation = minimax(depth - 1, true, alpha, beta);

            humanPos = oldHumanPos;
            board[move.r][move.c].owner = prevOwner;
            board[move.r][move.c].bonus = prevBonus;

            minEval = Math.min(minEval, evaluation);
            beta = Math.min(beta, evaluation);
            if (beta <= alpha) break;
        }
        return minEval;
    }
}

function evaluateBoard() {
    let aiScore = 0;
    let humanScore = 0;
    for (let r = 0; r < BOARD_SIZE; r++) {
        for (let c = 0; c < BOARD_SIZE; c++) {
            if (board[r][c].owner === 'ai') aiScore++;
            if (board[r][c].owner === 'human') humanScore++;
        }
    }
    return aiScore - humanScore;
}

function endGame() {
    isGameActive = false;
    let humanScore = parseInt(document.getElementById('human-score').textContent);
    let aiScore = parseInt(document.getElementById('ai-score').textContent);

    let message = "Game Over! ";
    if (humanScore > aiScore) {
        message += "You Win! 🏆";
    } else if (aiScore > humanScore) {
        message += "AI Wins! Better luck next time.";
    } else {
        message += "It's a Tie! 🤝";
    }
    document.getElementById('status').textContent = message;
}

function resetGame() {
    initGame();
}

// Auto start game on script load
initGame();
